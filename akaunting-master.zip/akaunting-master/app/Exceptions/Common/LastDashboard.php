<?php

namespace App\Exceptions\Common;

use Exception;

class LastDashboard extends Exception
{
    //
}
